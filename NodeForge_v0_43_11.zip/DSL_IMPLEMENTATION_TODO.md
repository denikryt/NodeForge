# NodeForge DSL Implementation TODO

This document tracks native DSL syntax, primitives, and tooling still missing after the `builtins/` refactor and the v0.43.x syntax pass.

Architecture boundary:

- `builtins/` is for base language primitives and direct/near-direct Blender node wrappers.
- `functions/` is for reusable library functions and recipes written in `.nf` or native package backends.
- `compiler.py` should dispatch to `builtins.registry` instead of hardcoding every builtin.

## Already implemented / no longer TODO

These were previously missing and are now implemented in the v0.43.x line:

- compile-time constant assignment name resolution
- `if / else` statement support for assignment blocks
- ternary expressions: `x if cond else y`
- script-level lists/arrays: `items = []`, `items.append(...)`, `join(items)`, `items[0]`
- compile-time array index through a constant variable, e.g. `idx = 1; items[idx]`
- tuple unpack in script-level array loops, e.g. `for x, y in [(0, 0), (1, 0)]`
- augmented assignments, e.g. `a += 1`
- local `def` functions compiled as separate node groups
- local functions can call other local functions
- keyword arguments for local `def` calls
- local functions returning `join([...])` with negative numeric parameters
- vector indexing: `v[0]`, `v[1]`, `v[2]`
- chained comparisons, e.g. `0 < x < 1`
- builtin math keywords such as `clamp(value=x, min=0, max=1)`
- `vector(x=..., y=..., z=...)` keyword arguments
- keyword output form, e.g. `output(name="Y", value=y)`
- `noise(...)`
- `random_value(...)`

## Mandelbrot-quality DSL target

Goal: make it possible to write a clean Mandelbrot set script in pure NodeForge DSL, without Python native backends and without manual index/mod/floor hacks.

Verified status before this TODO update:

- `runtime_range(...)` with several state variables already works.
- runtime float/int/bool state already works.
- runtime boolean expressions `not`, `and`, `or`, `==`, `!=`, comparisons already work.
- field math inside `runtime_range(...)` already works.
- `store(...)` exists as a statement form, but not as the preferred expression-form geometry operation.

Required implementation that is still missing:

### 1. `grid_points(width, height)`

Create a rectangular point grid with `width * height` points.

Expected behavior:

```python
pts = grid_points(width, height)
```

- Output type: geometry.
- `width` and `height` should support runtime inputs.
- Point order should be stable and row-major.
- Users should not have to derive 2D grid coordinates manually from a 1D `index()`.

### 2. `grid_uv()`

Return a vector field for the current grid point, normalized to `[0, 1]` in X/Y.

Expected behavior:

```python
uv = grid_uv()
cx = map_range(uv.x, 0, 1, -2.5, 1.0)
cy = map_range(uv.y, 0, 1, -1.5, 1.5)
```

- Output type: vector field.
- `uv.x` is horizontal normalized coordinate.
- `uv.y` is vertical normalized coordinate.
- `uv.z` can be `0`.
- `grid_uv()` should be tied to the most recent/current `grid_points(...)` context.

### 3. `if` blocks inside `runtime_range(...)`

The loop currently supports scalar state well, but Mandelbrot needs conditional state updates inside the runtime loop:

```python
for i in runtime_range(max_iter):
    zx_next = zx * zx - zy * zy + cx
    zy_next = 2 * zx * zy + cy
    mag2 = zx_next * zx_next + zy_next * zy_next

    if not escaped:
        zx = zx_next
        zy = zy_next
        escape_iter = i
        escaped = mag2 > 4
```

Required behavior:

- allow `if` blocks inside `runtime_range(...)`
- allow multiple assignments inside the runtime `if` block
- update state conditionally
- preserve previous state when the condition is false

### 4. `store_named_attribute(geometry, name, value)`

Add expression-form named attribute writing.

Expected behavior:

```python
pts = store_named_attribute(pts, "escape_iter", escape_iter)
```

- Output type: geometry.
- `name` must be a compile-time string.
- `value` can be int/float/vector/color field.
- It can map internally to Blender Store Named Attribute.
- This should coexist with the existing statement-form `store(...)`, but this expression form is cleaner for procedural pipelines.

### 5. Attribute-driven material / color support

Mandelbrot should use one material, not many materials. The geometry should store the
per-point/per-vertex `escape_iter` attribute, and a material should read that attribute
and map it to color through a ColorRamp or equivalent shader setup.

Target workflow:

```python
pts = store_named_attribute(pts, "escape_iter", escape_iter)
pts = set_material(pts, "NodeForge_Mandelbrot")
```

Expected behavior:

- one material is assigned to the generated Mandelbrot geometry
- the material reads the `escape_iter` named attribute
- color is driven by that attribute, so changing the material's ramp recolors the fractal
- geometry does not need to be rebuilt just to change the palette

This can be implemented as either:

- a general `set_material(geometry, material_name)` builtin plus a documented manual material setup, or
- a helper that creates a default NodeForge Mandelbrot material reading `escape_iter`

The preferred architecture is general first: `set_material(...)` and attribute-driven materials. A Mandelbrot-specific helper can come later as a convenience function.

Target Mandelbrot script after the five missing items above are implemented:

```python
width = input_int("Width", default=160)
height = input_int("Height", default=100)
max_iter = input_int("Max Iter", default=48)
z_scale = input_float("Z Scale", default=0.025)

pts = grid_points(width, height)

uv = grid_uv()
cx = map_range(uv.x, 0, 1, -2.5, 1.0)
cy = map_range(uv.y, 0, 1, -1.5, 1.5)

zx = 0
zy = 0
escaped = False
escape_iter = 0

for i in runtime_range(max_iter):
    zx_next = zx * zx - zy * zy + cx
    zy_next = 2 * zx * zy + cy
    mag2 = zx_next * zx_next + zy_next * zy_next

    if not escaped:
        zx = zx_next
        zy = zy_next
        escape_iter = i
        escaped = mag2 > 4

pts = set_position(
    pts,
    vector(cx, cy, escape_iter * z_scale)
)

pts = store_named_attribute(pts, "escape_iter", escape_iter)
pts = set_material(pts, "NodeForge_Mandelbrot")

output("Geometry", pts)
```

First implementation can still render as a height field before the material work is complete. The high-quality target is height plus `escape_iter` attribute plus one attribute-driven material.

## Remaining syntax / function gaps

### Function definition improvements

Basic local `def` works and compiles to separate node groups.

Still missing:

```python
def f(x, scale=1):
    return x * scale
```

Still not supported:

- default arguments
- `*args` / `**kwargs`
- recursion
- multiple returns

Keep library packages as the main mechanism for reusable public functions.

### Vector swizzles

Current access:

```python
v = position()
x = v.x
y = v.y
z = v.z
x2 = v[0]
```

Wanted:

```python
xy = position().xy
xz = position().xz
yz = position().yz
```

Expected implementation: separate XYZ and recombine selected components.

## High-value geometry primitives to add

### `named_attribute(...)`

Wanted examples:

```python
height = named_attribute("height")
mask = named_attribute("mask", type="float")
```

Expected Blender node target: `GeometryNodeInputNamedAttribute`.

Priority: medium-high. Needed for reading existing attributes from geometry.

### `delete_geometry(...)`

Wanted examples:

```python
geo = delete_geometry(geo, selection=position().z < 0)
geo = delete_geometry(geo, selection=random_value(0, 1, seed=index()) < 0.5)
```

Expected Blender node target: `GeometryNodeDeleteGeometry`.

Priority: high. Gives masking/filtering and generative carving.

### Mesh / curve primitive constructors

Current primitives are limited: `cube`, `points`, `polyline`, and planned `grid_points`.

Wanted:

```python
geo = circle(vertices=64, radius=1)
curve = curve_circle(radius=1)
line = curve_line(start=vector(0, 0, 0), end=vector(1, 0, 0))
```

Possible Blender node targets:

- Mesh Circle
- Curve Circle
- Curve Line
- UV Sphere / Ico Sphere

Priority: medium. Useful for examples and function packages.

### Geometry modification nodes

Wanted examples:

```python
geo = extrude_mesh(geo, offset=normal() * 0.1)
geo = subdivide_mesh(geo, level=2)
geo = merge_by_distance(geo, distance=0.001)
```

Priority: medium. Add only after the field/mask primitives are stable.

## Suggested next implementation order

1. Add `grid_points(width, height)` and `grid_uv()`.
2. Harden `runtime_range(...)` for multiple float/int/bool state variables and conditional updates.
3. Add stable runtime boolean operators: `not`, `and`, `or`, `==`, `!=`.
4. Add `store_named_attribute(...)`.
5. Add `delete_geometry(...)`.
6. Add `named_attribute(...)`.
7. Add `circle(...)` / `curve_circle(...)`.
8. Add vector swizzles.
9. Improve local `def` defaults.

## Non-goals for now

- Do not move library recipes like `copy_by_offsets`, `sierpinski_carpet`, `fibonacci`, or `dragon_curve` into `builtins/`.
- Do not add one file per single builtin unless the implementation becomes large.
- Do not add recursive functions until non-recursive local functions are stable.
